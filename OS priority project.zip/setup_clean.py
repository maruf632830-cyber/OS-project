#!/usr/bin/env python3

import sys
import os
import shutil

def read(path):
    with open(path, "r") as f:
        return f.read()

def write(path, text):
    with open(path, "w") as f:
        f.write(text)
    print(f"  [OK] {path}")

def patch(path, old, new, count=1):
    text = read(path)
    if old not in text:
        print(f"  [WARN] anchor not found in {path}: {repr(old[:60])}")
        return False
    text = text.replace(old, new, count)
    write(path, text)
    return True


PROC_H_OLD = '  char name[16];               // Process name (debugging)'
PROC_H_NEW = '''\
  char name[16];               // Process name (debugging)

  int  priority;
  uint64 runtime;
  uint64 waittime;
  uint64 starttime;
'''


PROC_C_CONST_ANCHOR = "// Must be called with interrupts disabled\n// to avoid the race between reading proc->pid"
PROC_C_CONST_NEW = """\
#define DEFAULT_PRIORITY  10
#define MAX_PRIORITY      20
#define MIN_PRIORITY       0
#define AGING_THRESHOLD   50

// Must be called with interrupts disabled
// to avoid the race between reading proc->pid"""

ALLOC_PROC_FOUND_OLD = "  p->context.ra = (uint64)forkret;\n  p->context.sp = p->kstack + PGSIZE;\n\n  return p;"
ALLOC_PROC_FOUND_NEW = """\
  p->context.ra = (uint64)forkret;
  p->context.sp = p->kstack + PGSIZE;

  p->priority  = DEFAULT_PRIORITY;
  p->runtime   = 0;
  p->waittime  = 0;
  acquire(&tickslock);
  p->starttime = ticks;
  release(&tickslock);

  return p;"""

NEW_SCHEDULER = """\
void
scheduler(void)
{
  struct proc *p;
  struct proc *chosen;
  struct cpu  *c = mycpu();
  uint64 start_tick;

  c->proc = 0;
  for(;;){
    intr_on();

    for(p = proc; p < &proc[NPROC]; p++){
      acquire(&p->lock);
      if(p->state == RUNNABLE){
        p->waittime++;
        if(p->waittime >= AGING_THRESHOLD && p->priority > MIN_PRIORITY){
          p->priority--;
          p->waittime = 0;
        }
      }
      release(&p->lock);
    }

    chosen    = 0;
    int best  = MAX_PRIORITY + 1;

    for(p = proc; p < &proc[NPROC]; p++){
      acquire(&p->lock);
      if(p->state == RUNNABLE && p->priority < best){
        best   = p->priority;
        chosen = p;
      }
      release(&p->lock);
    }

    if(chosen != 0){
      acquire(&chosen->lock);
      if(chosen->state == RUNNABLE){
        chosen->state    = RUNNING;
        chosen->waittime = 0;
        c->proc = chosen;

        start_tick = ticks;
        swtch(&c->context, &chosen->context);
        chosen->runtime += ticks - start_tick;

        c->proc = 0;
      }
      release(&chosen->lock);
    }
  }
}

"""

SYSCALL_H_OLD = "#define SYS_close  21"
SYSCALL_H_NEW = """\
#define SYS_close       21
#define SYS_setpriority 22
#define SYS_psinfo      23"""

SYSCALL_C_EXTERN_OLD = "extern uint64 sys_close(void);"
SYSCALL_C_EXTERN_NEW = """\
extern uint64 sys_close(void);
extern uint64 sys_setpriority(void);
extern uint64 sys_psinfo(void);"""

SYSCALL_C_TABLE_OLD = "[SYS_close]   sys_close,"
SYSCALL_C_TABLE_NEW = """\
[SYS_close]       sys_close,
[SYS_setpriority] sys_setpriority,
[SYS_psinfo]      sys_psinfo,"""

NEW_SYSPROC_FUNCS = """
#define MIN_PRIORITY  0
#define MAX_PRIORITY 20

uint64
sys_setpriority(void)
{
  int pid, priority;
  if(argint(0, &pid) < 0 || argint(1, &priority) < 0)
    return -1;
  if(priority < MIN_PRIORITY || priority > MAX_PRIORITY)
    return -1;

  struct proc *p;
  for(p = proc; p < &proc[NPROC]; p++){
    acquire(&p->lock);
    if(p->pid == pid){
      p->priority = priority;
      p->waittime = 0;
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
  }
  return -1;
}

uint64
sys_psinfo(void)
{
  static const char *state_names[] = {
    [UNUSED]   "UNUSED  ",
    [SLEEPING] "SLEEP   ",
    [RUNNABLE] "RUNNABLE",
    [RUNNING]  "RUNNING ",
    [ZOMBIE]   "ZOMBIE  ",
  };

  struct proc *p;
  int count = 0;

  printf("\\n%-6s %-16s %-8s %8s %12s %12s\\n",
         "PID", "NAME", "STATE", "PRIORITY", "RUNTIME", "STARTTIME");
  printf("------------------------------------------------------------------\\n");

  for(p = proc; p < &proc[NPROC]; p++){
    acquire(&p->lock);
    if(p->state != UNUSED){
      const char *st = (p->state >= 0 && p->state < 5)
                       ? state_names[p->state]
                       : "???     ";
      printf("%-6d %-16s %-8s %8d %12lu %12lu\\n",
             p->pid, p->name, st,
             p->priority, p->runtime, p->starttime);
      count++;
    }
    release(&p->lock);
  }
  printf("\\n");
  return count;
}
"""

USER_H_OLD = "int uptime(void);"
USER_H_NEW = """\
int uptime(void);
int setpriority(int, int);
int psinfo(void);"""

USYS_PL_OLD = 'entry("uptime");'
USYS_PL_NEW = '''\
entry("uptime");
entry("setpriority");
entry("psinfo");'''

MAKEFILE_OLD = "\t$U/_zombie\\"
MAKEFILE_NEW = """\
\t$U/_zombie\\
\t$U/_testpriority\\
\t$U/_testpsinfo\\"""

TESTPRIORITY_C = r"""#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

#define WORK_UNITS 200000000

static void
spin(int n)
{
  volatile long x = 0;
  for(long i = 0; i < n; i++)
    x += i;
  (void)x;
}

int
main(void)
{
  printf("testpriority: starting\n");

  int pids[3];
  int prios[3] = {5, 10, 15};

  for(int i = 0; i < 3; i++){
    int pid = fork();
    if(pid == 0){
      if(setpriority(getpid(), prios[i]) < 0)
        printf("  child %d: setpriority failed\n", getpid());
      printf("  child pid=%d priority=%d starting work\n",
             getpid(), prios[i]);
      spin(WORK_UNITS);
      printf("  child pid=%d priority=%d DONE\n", getpid(), prios[i]);
      exit(0);
    } else {
      pids[i] = pid;
      printf("parent: forked pid=%d with priority=%d\n", pid, prios[i]);
    }
  }

  for(int i = 0; i < 3; i++)
    wait(0);

  printf("testpriority: done\n");
  exit(0);
}
"""

TESTPSINFO_C = r"""#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int
main(void)
{
  printf("testpsinfo: calling psinfo() before fork\n");
  psinfo();

  int pid1 = fork();
  if(pid1 == 0){
    setpriority(getpid(), 3);
    printf("child1 (pid=%d, prio=3): sleeping briefly\n", getpid());
    sleep(5);
    exit(0);
  }

  int pid2 = fork();
  if(pid2 == 0){
    setpriority(getpid(), 18);
    printf("child2 (pid=%d, prio=18): sleeping briefly\n", getpid());
    sleep(5);
    exit(0);
  }

  sleep(1);

  printf("testpsinfo: calling psinfo() with children alive\n");
  psinfo();

  setpriority(getpid(), 7);
  printf("parent: set own priority to 7\n");

  psinfo();

  wait(0);
  wait(0);

  printf("testpsinfo: done\n");
  exit(0);
}
"""

def main():
  if len(sys.argv) != 2:
    print("Usage: python3 setup.py <path-to-xv6-riscv-directory>")
    sys.exit(1)

  xv6 = sys.argv[1].rstrip("/")
  if not os.path.isdir(xv6):
    print(f"Error: '{xv6}' is not a directory.")
    sys.exit(1)

  print(f"\n=== Patching xv6-riscv at: {xv6} ===\n")

  print("[1] kernel/proc.h — adding struct proc fields")
  patch(f"{xv6}/kernel/proc.h", PROC_H_OLD, PROC_H_NEW)

  print("[2] kernel/proc.c — constants, allocproc init, scheduler")
  f = f"{xv6}/kernel/proc.c"
  patch(f, PROC_C_CONST_ANCHOR, PROC_C_CONST_NEW)
  patch(f, ALLOC_PROC_FOUND_OLD, ALLOC_PROC_FOUND_NEW)
  text = read(f)
  start = text.find("void\nscheduler(void)\n{")
  end   = text.find("// Enter scheduler.  Must hold only p->lock")
  if start == -1 or end == -1:
    end = text.find("\n// Enter scheduler.")
  if start != -1 and end != -1:
    old_sched = text[start:end]
    text = text[:start] + NEW_SCHEDULER + text[end:]
    write(f, text)
  else:
    print("  [WARN] Could not locate scheduler() boundaries in proc.c")

  print("[3] kernel/syscall.h — adding SYS_setpriority, SYS_psinfo")
  patch(f"{xv6}/kernel/syscall.h", SYSCALL_H_OLD, SYSCALL_H_NEW)

  print("[4] kernel/syscall.c — extern declarations and dispatch table")
  f = f"{xv6}/kernel/syscall.c"
  patch(f, SYSCALL_C_EXTERN_OLD, SYSCALL_C_EXTERN_NEW)
  patch(f, SYSCALL_C_TABLE_OLD,  SYSCALL_C_TABLE_NEW)

  print("[5] kernel/sysproc.c — sys_setpriority and sys_psinfo")
  f = f"{xv6}/kernel/sysproc.c"
  text = read(f)
  text = text.rstrip() + "\n\n" + NEW_SYSPROC_FUNCS + "\n"
  write(f, text)

  print("[6] user/user.h — adding setpriority and psinfo declarations")
  patch(f"{xv6}/user/user.h", USER_H_OLD, USER_H_NEW)

  print("[7] user/usys.pl — adding syscall stubs")
  patch(f"{xv6}/user/usys.pl", USYS_PL_OLD, USYS_PL_NEW)

  print("[8] Makefile — adding _testpriority and _testpsinfo to UPROGS")
  patch(f"{xv6}/Makefile", MAKEFILE_OLD, MAKEFILE_NEW)

  print("[9] Creating user/testpriority.c")
  write(f"{xv6}/user/testpriority.c", TESTPRIORITY_C)
  print("[9] Creating user/testpsinfo.c")
  write(f"{xv6}/user/testpsinfo.c", TESTPSINFO_C)

  print("\n=== Patching complete! ===\n")


if __name__ == "__main__":
  main()
