#define DEFAULT_PRIORITY  10
#define MAX_PRIORITY      20
#define MIN_PRIORITY       0
#define AGING_THRESHOLD   50

void
scheduler(void)
{
  struct proc *p;
  struct proc *chosen;
  struct cpu  *c = mycpu();
  uint64 start_tick;

  c->proc = 0;
  for(;;){
    intr_on();

    for(p = proc; p < &proc[NPROC]; p++){
      acquire(&p->lock);
      if(p->state == RUNNABLE){
        p->waittime++;
        if(p->waittime >= AGING_THRESHOLD && p->priority > MIN_PRIORITY){
          p->priority--;
          p->waittime = 0;
        }
      }
      release(&p->lock);
    }

    chosen    = 0;
    int best  = MAX_PRIORITY + 1;

    for(p = proc; p < &proc[NPROC]; p++){
      acquire(&p->lock);
      if(p->state == RUNNABLE && p->priority < best){
        best   = p->priority;
        chosen = p;
      }
      release(&p->lock);
    }

    if(chosen != 0){
      acquire(&chosen->lock);
      if(chosen->state == RUNNABLE){
        chosen->state    = RUNNING;
        chosen->waittime = 0;
        c->proc = chosen;

        start_tick = ticks;
        swtch(&c->context, &chosen->context);
        chosen->runtime += ticks - start_tick;

        c->proc = 0;
      }
      release(&chosen->lock);
    }
  }
}
