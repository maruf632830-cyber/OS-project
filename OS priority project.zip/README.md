# xv6 Enhanced Priority Scheduler — Project README

## Overview

This project enhances the [xv6-riscv](https://github.com/mit-pdos/xv6-riscv)
operating system with:

| Feature | Description |
|---|---|
| **Priority-based scheduler** | Replaces default Round-Robin; selects the highest-urgency RUNNABLE process |
| **Round-Robin for equal priority** | Processes at the same priority level are time-shared in array order |
| **Aging** | A RUNNABLE process that waits ≥ 50 ticks gets its priority boosted by 1, preventing starvation |
| **`setpriority(pid, p)`** | New system call — dynamically changes a process's priority at runtime |
| **`psinfo()`** | New system call — prints a snapshot of the live process table to the console |
| **Runtime tracking** | Every process records total CPU ticks consumed (`runtime` field) |

Priority range: **0 (highest urgency) → 20 (lowest urgency)**, default = **10**.

---

## Prerequisites

- QEMU with RISC-V support (`qemu-system-riscv64`)
- RISC-V cross-compiler (`riscv64-linux-gnu-gcc` or `riscv64-unknown-elf-gcc`)
- A clean clone of **xv6-riscv**

Installation guide (Linux/macOS):
<https://www.cse.iitb.ac.in/~mythili/os/xv6.html>

---

## Setup — Applying the Patches

```bash
# 1. Clone xv6-riscv (if you haven't already)
git clone https://github.com/mit-pdos/xv6-riscv.git

# 2. Run the setup script from this project's root directory
python3 setup.py xv6-riscv          # or whatever path you cloned to

# 3. Build and run
cd xv6-riscv
make clean && make qemu
```

The script applies all patches and copies the test programs automatically.
It prints `[OK]` for each file it modifies and instructions at the end.

---

## Files Changed / Added

### Modified kernel files

| File | Change |
|---|---|
| `kernel/proc.h` | Added `priority`, `runtime`, `waittime`, `starttime` to `struct proc` |
| `kernel/proc.c` | Added scheduler constants; initialised new fields in `allocproc()`; replaced `scheduler()` |
| `kernel/syscall.h` | Added `SYS_setpriority = 22`, `SYS_psinfo = 23` |
| `kernel/syscall.c` | Added extern declarations and dispatch table entries |
| `kernel/sysproc.c` | Appended `sys_setpriority()` and `sys_psinfo()` |

### Modified user-space files

| File | Change |
|---|---|
| `user/user.h` | Added `setpriority(int, int)` and `psinfo(void)` declarations |
| `user/usys.pl` | Added `entry("setpriority")` and `entry("psinfo")` stubs |
| `Makefile` | Added `$U/_testpriority` and `$U/_testpsinfo` to `UPROGS` |

### New files

| File | Purpose |
|---|---|
| `user/testpriority.c` | Tests scheduler priority ordering + dynamic `setpriority()` |
| `user/testpsinfo.c` | Tests `psinfo()` output and priority changes |

---

## Running the Tests

Inside the xv6 shell (after `make qemu`):

```
$ testpriority
testpriority: starting (parent pid=3)
testpriority: spawning 3 children at priorities 5, 10, 15

  child pid=4     priority=5    [started]
  child pid=5     priority=10   [started]
  child pid=6     priority=15   [started]
  child pid=4     priority=5    [FINISHED]   ← first, as expected
  child pid=5     priority=10   [FINISHED]
  child pid=6     priority=15   [FINISHED]

testpriority: all children done
Expected finish order: priority 5 -> 10 -> 15
testpriority: PASS
```

```
$ testpsinfo
testpsinfo: process table before any forks:

PID    NAME             STATE    PRIORITY      RUNTIME    STARTTIME
------------------------------------------------------------------
1      init             SLEEP           10            8            0
2      sh               SLEEP           10           45            3
3      testpsinfo       RUNNING         10            2           51
...

testpsinfo: PASS
```

---

## Design Details

### Scheduling Algorithm

```
for each scheduler loop iteration:
  1. AGING PASS — for every RUNNABLE proc:
       waittime++
       if waittime >= 50 and priority > 0:
           priority--   (boost: lower number = higher urgency)
           waittime = 0

  2. SELECTION PASS — find proc with smallest priority number
       (ties resolved by process-table array order → approximate RR)

  3. RUN — context-switch to chosen proc; track start_tick..end_tick → runtime
```

### System Calls

#### `int setpriority(int pid, int priority)`
- Argument validation: priority must be in `[0, 20]`
- Acquires `p->lock`, updates `p->priority` and resets `p->waittime`
- Returns `0` on success, `-1` if pid not found or args invalid

#### `int psinfo(void)`
- Iterates `proc[]`, acquires each lock, prints one row per non-UNUSED process
- Columns: PID, NAME, STATE, PRIORITY, RUNTIME (ticks), STARTTIME (tick)
- Returns number of live processes printed

### Starvation Prevention

With `AGING_THRESHOLD = 50`, a low-priority process that has been
waiting for 50 scheduler ticks will have its priority incremented by 1
(numerically decremented). This repeats until the process is eventually
selected. Worst-case wait before reaching priority 0 from priority 20:
20 × 50 = 1000 scheduler iterations.

---

## Known Limitations

1. The scheduler runs on a single CPU (QEMU default). On multi-CPU
   configurations, two CPUs could independently select the same
   process between the scan and run phases; the second acquire detects
   this via the `state == RUNNABLE` re-check and safely skips.
2. `psinfo()` prints to the kernel console via `printf`; output appears
   in the same terminal as xv6. This is by design for simplicity.
3. `runtime` counts scheduler-loop ticks, not wall-clock milliseconds.
   To convert: multiply by the timer interval (default ~10 ms in xv6).

---

## References

- xv6-riscv source: <https://github.com/mit-pdos/xv6-riscv>
- xv6 book (RISC-V edition): <https://pdos.csail.mit.edu/6.828/2025/xv6/book-riscv-rev5.pdf>
- OSTEP xv6 projects: <https://pages.cs.wisc.edu/~remzi/OSTEP/lab-projects-xv6.pdf>
- IIT Bombay xv6 guide: <https://www.cse.iitb.ac.in/~mythili/os/xv6.html>
