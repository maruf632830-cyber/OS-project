// ============================================================
// FILE: kernel/proc.c  — ADDITIONS / REPLACEMENTS
// This file shows ONLY what changes.  setup.py applies them
// automatically.  Read this for understanding / manual patching.
// ============================================================

// ── A. Add these constants near the top of proc.c ────────────────────────────
//    (before the allocproc function, after the #include block)

#define DEFAULT_PRIORITY  10   // initial priority for every new process
#define MAX_PRIORITY      20   // lowest urgency (largest number)
#define MIN_PRIORITY       0   // highest urgency (smallest number)
#define AGING_THRESHOLD   50   // ticks RUNNABLE before a priority boost

// ── B. In allocproc(), add after  p->context.sp = p->kstack + PGSIZE; ────────

  p->priority  = DEFAULT_PRIORITY;
  p->runtime   = 0;
  p->waittime  = 0;
  acquire(&tickslock);
  p->starttime = ticks;
  release(&tickslock);

// ── C. Replace the entire scheduler() function with this ─────────────────────

// Priority scheduler with aging and Round-Robin for equal-priority processes.
//
// Algorithm:
//   1. Age every RUNNABLE process (+1 waittime per loop iteration).
//      When waittime reaches AGING_THRESHOLD and priority > MIN_PRIORITY,
//      boost priority by 1 (decrement the number) and reset waittime.
//   2. Find the RUNNABLE process with the smallest priority number.
//      Ties break in process-table order (approximates Round-Robin because
//      the currently running process is RUNNING, not RUNNABLE).
//   3. Run that process; record CPU ticks consumed.
void
scheduler(void)
{
  struct proc *p;
  struct proc *chosen;
  struct cpu  *c = mycpu();
  uint64 start_tick;

  c->proc = 0;
  for(;;){
    // Enable interrupts so devices can interrupt while we search.
    intr_on();

    // ── Step 1: Aging ────────────────────────────────────────────────────────
    for(p = proc; p < &proc[NPROC]; p++){
      acquire(&p->lock);
      if(p->state == RUNNABLE){
        p->waittime++;
        if(p->waittime >= AGING_THRESHOLD && p->priority > MIN_PRIORITY){
          p->priority--;   // promote: lower number = higher urgency
          p->waittime = 0;
        }
      }
      release(&p->lock);
    }

    // ── Step 2: Find highest-priority RUNNABLE process ───────────────────────
    chosen   = 0;
    int best = MAX_PRIORITY + 1;

    for(p = proc; p < &proc[NPROC]; p++){
      acquire(&p->lock);
      if(p->state == RUNNABLE && p->priority < best){
        best   = p->priority;
        chosen = p;
      }
      release(&p->lock);
    }

    // ── Step 3: Run the chosen process ───────────────────────────────────────
    if(chosen != 0){
      acquire(&chosen->lock);
      // Re-check state; it may have changed between step 2 and 3.
      if(chosen->state == RUNNABLE){
        chosen->state    = RUNNING;
        chosen->waittime = 0;   // reset aging when scheduled
        c->proc = chosen;

        start_tick = ticks;                       // begin runtime measurement
        swtch(&c->context, &chosen->context);
        chosen->runtime += ticks - start_tick;    // accumulate CPU time

        c->proc = 0;
      }
      release(&chosen->lock);
    }
  }
}
