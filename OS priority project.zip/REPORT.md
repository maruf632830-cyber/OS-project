# Project Report
## Enhanced Priority-Based Scheduling and Process Monitoring System in xv6

---

## 1. Introduction

This report describes the design and implementation of two features added to the
xv6-riscv operating system:

1. **Priority-Based Scheduler** with Round-Robin fairness and aging-based starvation
   prevention.
2. **Process Monitoring System** with runtime tracking and the `psinfo()` system call.

The goal is to replace xv6's default Round-Robin scheduler with an intelligent,
priority-aware dispatcher that mirrors real-world OS designs while remaining
readable and educational.

---

## 2. Background and Motivation

The default xv6 scheduler iterates through the `proc[]` array and selects the
first RUNNABLE process it finds — a simple Round-Robin that allocates equal CPU
time to every process regardless of urgency or importance.

Real operating systems (Linux's CFS, Windows' multi-level priority queues,
UNIX nice values) treat processes differently based on the kind of work they do.
Interactive and real-time tasks need low latency; background batch jobs can wait.
Without a priority mechanism, xv6 cannot simulate or study these behaviours.

Additionally, xv6 provides no runtime visibility: there is no way for a user
program to inspect what processes are running or how much CPU they have consumed.
The `psinfo()` system call addresses this gap.

---

## 3. Implementation

### 3.1 Data Structures (`kernel/proc.h`)

Four fields were added to `struct proc`:

| Field | Type | Purpose |
|---|---|---|
| `priority` | `int` | Scheduling urgency: 0 (highest) – 20 (lowest) |
| `runtime` | `uint64` | Cumulative CPU ticks consumed |
| `waittime` | `uint64` | Consecutive ticks spent RUNNABLE (aging counter) |
| `starttime` | `uint64` | Absolute tick when the process was created |

All fields are initialised in `allocproc()`. `priority` defaults to **10**
(mid-range); `runtime` and `waittime` start at 0; `starttime` is set to the
current value of the global `ticks` counter (acquired under `tickslock`).

### 3.2 Priority Scheduler (`kernel/proc.c`)

The `scheduler()` function was fully replaced. Each iteration of the outer loop
executes three steps:

**Step 1 — Aging pass.**
Every RUNNABLE process has its `waittime` incremented. If `waittime` reaches
`AGING_THRESHOLD` (50) and `priority > 0`, the priority is boosted by 1
(numerically decremented) and `waittime` is reset to zero. This ensures no
process starves indefinitely, no matter how many high-priority processes exist.

**Step 2 — Selection pass.**
The process table is scanned to find the RUNNABLE process with the smallest
`priority` value (= highest urgency). Ties are broken by position in the
`proc[]` array. Because the currently executing process is in state `RUNNING`
(not `RUNNABLE`), it is invisible to the selection pass; on the next iteration
it will be RUNNABLE again and eligible. This provides implicit Round-Robin
among equal-priority processes.

**Step 3 — Dispatch.**
The chosen process's `state` is set to `RUNNING`, its `waittime` is reset to 0,
and `swtch()` transfers control to it. Before calling `swtch()`, the current
value of `ticks` is saved; after `swtch()` returns (the process yielded or was
preempted), `ticks - start_tick` is added to `chosen->runtime`.

The re-check `if(chosen->state == RUNNABLE)` between steps 2 and 3 guards
against a race on multi-core configurations where another CPU may have
dispatched the same process in the small window between the scan and the
acquire.

```
Scheduling constants
--------------------
DEFAULT_PRIORITY  = 10   (assigned to every new process)
MIN_PRIORITY      =  0   (highest urgency)
MAX_PRIORITY      = 20   (lowest urgency)
AGING_THRESHOLD   = 50   (ticks before priority boost)
```

### 3.3 System Call: `setpriority(int pid, int priority)` (`kernel/sysproc.c`)

`sys_setpriority` reads two integer arguments from user registers via
`argint()`. It validates that priority lies in `[0, 20]`, then searches the
`proc[]` array for the matching PID. When found, it acquires `p->lock`,
updates `p->priority`, resets `p->waittime` to 0 (so that a manual
downgrade is not immediately reversed by accumulated aging), and releases
the lock. Returns 0 on success, −1 on any error.

Syscall numbers allocated in `kernel/syscall.h`:
- `SYS_setpriority = 22`
- `SYS_psinfo      = 23`

### 3.4 System Call: `psinfo(void)` (`kernel/sysproc.c`)

`sys_psinfo` iterates over the full `proc[]` array. For each non-`UNUSED`
process it acquires the lock, reads the required fields, releases the lock,
and prints one formatted row via kernel `printf`. The output columns are:

```
PID    NAME             STATE    PRIORITY      RUNTIME    STARTTIME
```

The function returns the count of live processes. Printing is done from
kernel space because xv6's user-space `printf` is not accessible in
`sysproc.c`; output is visible on the QEMU console where xv6 itself runs.

### 3.5 Plumbing

| File | Change |
|---|---|
| `kernel/syscall.h` | Added `#define SYS_setpriority 22` and `SYS_psinfo 23` |
| `kernel/syscall.c` | Added extern declarations and dispatch-table entries `[22]` and `[23]` |
| `user/user.h` | Added `int setpriority(int, int)` and `int psinfo(void)` |
| `user/usys.pl` | Added `entry("setpriority")` and `entry("psinfo")` RISC-V trampoline stubs |
| `Makefile` | Added `$U/_testpriority` and `$U/_testpsinfo` to `UPROGS` |

---

## 4. Testing and Evaluation

### 4.1 Priority Ordering Test (`testpriority`)

Three child processes are forked. Each immediately calls `setpriority(getpid(), p)`
with priorities 5, 10, and 15 respectively, then performs an identical
CPU-bound busy loop.

**Expected result:** The child with priority 5 finishes first, followed by
priority 10, then priority 15. This was consistently observed in QEMU runs,
confirming that the scheduler correctly selects the highest-urgency RUNNABLE
process.

### 4.2 Dynamic Priority Test

A child process starts with priority 15, performs a short sleep, then calls
`setpriority(getpid(), 2)` to boost itself. After the boost, it finishes ahead
of any other process at priority > 2. This validates that `setpriority()` takes
effect immediately (the process becomes eligible in the next scheduler loop).

### 4.3 Process Monitoring Test (`testpsinfo`)

`testpsinfo` forks two children at priorities 3 and 18, waits for them to sleep,
then calls `psinfo()`. The output shows all three processes (parent + two children)
with correct PID, name, state (RUNNING / SLEEP), priority, runtime, and starttime.

After the parent calls `setpriority(getpid(), 7)`, a subsequent `psinfo()` call
reflects the updated value, confirming that the kernel correctly stores and
reports dynamic priority changes.

### 4.4 Starvation Prevention Test

Ten processes were spawned at priority 20 alongside one process at priority 0.
After the priority-0 process completed, the priority-20 processes were all
eventually scheduled — the aging mechanism boosted each one to priority 0 after
at most 20 × 50 = 1000 scheduler iterations. No process remained indefinitely
unscheduled.

### 4.5 Round-Robin Fairness

Five processes were spawned all at priority 10. Each performed equal work.
Monitoring `runtime` values via `psinfo()` showed that all five accumulated
nearly identical tick counts, confirming Round-Robin behaviour among
equal-priority processes.

---

## 5. Challenges and Solutions

| Challenge | Solution |
|---|---|
| Lock-ordering during scheduler scan | Individual per-process `acquire`/`release` in both passes; re-check `state == RUNNABLE` before dispatch to handle TOCTOU window |
| Runtime measurement | Read `ticks` (guarded by `tickslock` at creation time; read-only in hot scheduler path) before/after `swtch()`; accumulate difference into `p->runtime` |
| Starvation with many high-priority processes | Aging: every 50 ticks of waiting, priority is boosted by 1; guaranteed to reach priority 0 in finite time |
| `setpriority` affecting already-running process | Priority updated under `p->lock`; effective on next scheduler loop because the running process will yield and be re-evaluated |
| Printing process table from kernel | Used kernel `printf` in `sys_psinfo()`; output appears on the same QEMU console, which is fully visible to the user |

---

## 6. Conclusion

The project successfully replaces xv6's default Round-Robin scheduler with a
priority-based system that:

- Respects priorities set at process-creation time or dynamically via `setpriority()`
- Maintains fairness among equal-priority processes via implicit Round-Robin
- Prevents starvation through an aging mechanism
- Provides real-time process introspection via `psinfo()`
- Tracks per-process CPU consumption in the `runtime` field

The implementation required changes across six kernel files and two user-space
files. All changes are backward-compatible: processes that never call
`setpriority()` run at priority 10 and behave identically to the original
Round-Robin scheduler. The two test programs (`testpriority`, `testpsinfo`)
serve as both functional tests and usage examples.

This project demonstrates the core tension in scheduler design — efficiency vs.
fairness — and shows how aging resolves it in a principled way, mirroring
techniques used in production operating systems.

---

## References

1. Cox, R., Kaashoek, F., Morris, R. *xv6: a simple, Unix-like teaching OS
   (RISC-V edition)*. MIT, 2023.
   <https://pdos.csail.mit.edu/6.828/2025/xv6/book-riscv-rev5.pdf>
2. Arpaci-Dusseau, R. H., Arpaci-Dusseau, A. C. *Operating Systems: Three Easy
   Pieces*. Chapter 8 (Scheduling: The Multi-Level Feedback Queue), 2023.
   <https://pages.cs.wisc.edu/~remzi/OSTEP/>
3. MIT 6.828 xv6 lab projects.
   <https://pages.cs.wisc.edu/~remzi/OSTEP/lab-projects-xv6.pdf>
4. IIT Bombay OS course — xv6 setup and system-call tutorial.
   <https://www.cse.iitb.ac.in/~mythili/os/xv6.html>
