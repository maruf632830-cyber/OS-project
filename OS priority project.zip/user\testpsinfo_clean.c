#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int
main(void)
{
  printf("testpsinfo: calling psinfo() before fork\n");
  psinfo();

  int pid1 = fork();
  if(pid1 == 0){
    setpriority(getpid(), 3);
    printf("child1 (pid=%d, prio=3): sleeping briefly\n", getpid());
    sleep(5);
    exit(0);
  }

  int pid2 = fork();
  if(pid2 == 0){
    setpriority(getpid(), 18);
    printf("child2 (pid=%d, prio=18): sleeping briefly\n", getpid());
    sleep(5);
    exit(0);
  }

  sleep(1);

  printf("testpsinfo: calling psinfo() with children alive\n");
  psinfo();

  setpriority(getpid(), 7);
  printf("parent: set own priority to 7\n");

  psinfo();

  wait(0);
  wait(0);

  printf("testpsinfo: done\n");
  exit(0);
}
