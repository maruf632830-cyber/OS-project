# xv6 Priority Scheduler - Implementation Report

## Project Overview

Enhanced priority-based scheduler for xv6-riscv with process monitoring capabilities.

## Implementation Details

### Data Structures
- priority: int (0-20, lower = higher urgency)
- runtime: uint64 (CPU ticks consumed)
- waittime: uint64 (aging counter)
- starttime: uint64 (process creation time)

### Scheduler Algorithm

1. Aging Pass: Increment waittime for RUNNABLE processes
   - If waittime >= AGING_THRESHOLD and priority > MIN_PRIORITY, boost priority
   
2. Selection Pass: Find RUNNABLE process with smallest priority value

3. Dispatch: Run selected process and track CPU consumption

### System Calls

sys_setpriority(int pid, int priority)
- Sets process priority to specified value
- Returns 0 on success, -1 on error

sys_psinfo(void)
- Prints process table snapshot
- Returns count of live processes

### Constants
- DEFAULT_PRIORITY = 10
- MIN_PRIORITY = 0
- MAX_PRIORITY = 20
- AGING_THRESHOLD = 50 ticks

## Testing

testpriority: Spawns 3 children at different priorities to verify scheduling order

testpsinfo: Demonstrates psinfo() output and dynamic priority changes
