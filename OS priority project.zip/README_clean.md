# xv6 Enhanced Priority Scheduler

## Overview

Priority-based scheduler for xv6-riscv operating system with features:
- Priority-based scheduling (0 = highest to 20 = lowest, default = 10)
- Round-Robin for equal priority processes
- Aging mechanism to prevent starvation
- setpriority(pid, p) system call
- psinfo() system call for process monitoring
- Runtime tracking per process

## Prerequisites

- QEMU with RISC-V support (qemu-system-riscv64)
- RISC-V cross-compiler (riscv64-linux-gnu-gcc or riscv64-unknown-elf-gcc)
- xv6-riscv source

## Setup

1. Clone xv6-riscv:
   git clone https://github.com/mit-pdos/xv6-riscv.git

2. Run setup script:
   python3 setup_clean.py xv6-riscv

3. Build and run:
   cd xv6-riscv
   make clean && make qemu

## Files Changed

### Kernel Files
- kernel/proc.h: Added priority, runtime, waittime, starttime to struct proc
- kernel/proc.c: Replaced scheduler, added initialization
- kernel/syscall.h: Added SYS_setpriority, SYS_psinfo
- kernel/syscall.c: Added dispatch entries
- kernel/sysproc.c: Added sys_setpriority and sys_psinfo

### User Files
- user/user.h: Added function declarations
- user/usys.pl: Added syscall stubs
- Makefile: Added test programs

## Tests

Inside xv6 shell after make qemu:
- testpriority: Verify scheduler ordering
- testpsinfo: Test process information display
