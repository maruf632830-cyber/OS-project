#!/usr/bin/env python3
"""
setup.py — Patches an xv6-riscv source tree to add:
  • Priority-based scheduler (0 = highest, 20 = lowest, default = 10)
  • Round-Robin among equal-priority processes
  • Aging to prevent starvation
  • setpriority(pid, priority) system call
  • psinfo() system call (prints full process table)
  • Runtime tracking (CPU ticks per process)
  • Two user test programs: testpriority, testpsinfo

Usage:
    python3 setup.py <path-to-xv6-riscv-directory>

Example:
    python3 setup.py ~/xv6-riscv
"""

import sys
import os
import shutil

# ─────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────

def read(path):
    with open(path, "r") as f:
        return f.read()

def write(path, text):
    with open(path, "w") as f:
        f.write(text)
    print(f"  [OK] {path}")

def patch(path, old, new, count=1):
    text = read(path)
    if old not in text:
        print(f"  [WARN] anchor not found in {path}: {repr(old[:60])}")
        return False
    text = text.replace(old, new, count)
    write(path, text)
    return True


# ─────────────────────────────────────────────────────────
# 1.  kernel/proc.h  — add fields to struct proc
# ─────────────────────────────────────────────────────────

PROC_H_OLD = '  char name[16];               // Process name (debugging)'
PROC_H_NEW = '''\
  char name[16];               // Process name (debugging)

  // ── Priority scheduling & monitoring (added) ──────────
  int  priority;   // Scheduling priority: 0 (highest) – 20 (lowest), default 10
  uint64 runtime;  // Total CPU ticks consumed by this process
  uint64 waittime; // Consecutive ticks spent RUNNABLE (used by aging)
  uint64 starttime;// System tick at which the process was created
'''


# ─────────────────────────────────────────────────────────
# 2.  kernel/proc.c  — constants + allocproc init + scheduler
# ─────────────────────────────────────────────────────────

# 2a. Insert scheduling constants after the first #include block.
#     We look for the existing "// Must be called with..." comment that
#     immediately precedes allocproc, so constants appear right before it.
PROC_C_CONST_ANCHOR = "// Must be called with interrupts disabled\n// to avoid the race between reading proc->pid"
PROC_C_CONST_NEW = """\
// ── Priority-scheduler constants ─────────────────────────────────────────────
#define DEFAULT_PRIORITY  10   // initial priority assigned to every new process
#define MAX_PRIORITY      20   // lowest urgency (numerically highest)
#define MIN_PRIORITY       0   // highest urgency (numerically lowest)
#define AGING_THRESHOLD   50   // ticks a RUNNABLE process waits before a boost

// ─────────────────────────────────────────────────────────────────────────────
// Must be called with interrupts disabled
// to avoid the race between reading proc->pid"""

# 2b. initialise new fields at the end of allocproc(), just before "return p;"
ALLOC_PROC_OLD = """\
  p->state = UNUSED;
  return 0;
}"""

# This anchor is fragile; use the pattern just before "return p;" inside
# allocproc.  A safer anchor is the last thing set before return:
ALLOC_PROC_FOUND_OLD = "  p->context.ra = (uint64)forkret;\n  p->context.sp = p->kstack + PGSIZE;\n\n  return p;"
ALLOC_PROC_FOUND_NEW = """\
  p->context.ra = (uint64)forkret;
  p->context.sp = p->kstack + PGSIZE;

  // ── Priority scheduling init ──────────────────────────
  p->priority  = DEFAULT_PRIORITY;
  p->runtime   = 0;
  p->waittime  = 0;
  acquire(&tickslock);
  p->starttime = ticks;
  release(&tickslock);

  return p;"""

# 2c. Replace the entire scheduler() function
SCHED_OLD_START = "void\nscheduler(void)\n{"
SCHED_OLD_END   = "}\n\n// Enter scheduler."   # first line after scheduler

NEW_SCHEDULER = """\
// Priority scheduler with aging and Round-Robin for equal-priority processes.
//
// Algorithm:
//   1. Age every RUNNABLE process (+1 waittime per outer loop iteration).
//      When waittime reaches AGING_THRESHOLD, boost priority by 1 (lower number).
//   2. Scan the process table to find the RUNNABLE process with the smallest
//      priority number (= highest urgency).  Ties are broken by process-table
//      order, which approximates Round-Robin because the running process is
//      RUNNING (not RUNNABLE) and is therefore skipped on the next iteration.
//   3. Run that process; track its CPU-tick consumption.
void
scheduler(void)
{
  struct proc *p;
  struct proc *chosen;
  struct cpu  *c = mycpu();
  uint64 start_tick;

  c->proc = 0;
  for(;;){
    // Enable interrupts so devices can interrupt while we look for a process.
    intr_on();

    // ── Step 1: Aging ────────────────────────────────────────────────────────
    for(p = proc; p < &proc[NPROC]; p++){
      acquire(&p->lock);
      if(p->state == RUNNABLE){
        p->waittime++;
        if(p->waittime >= AGING_THRESHOLD && p->priority > MIN_PRIORITY){
          p->priority--;   // promote: lower number = higher urgency
          p->waittime = 0;
        }
      }
      release(&p->lock);
    }

    // ── Step 2: Find highest-priority RUNNABLE process ───────────────────────
    chosen    = 0;
    int best  = MAX_PRIORITY + 1;

    for(p = proc; p < &proc[NPROC]; p++){
      acquire(&p->lock);
      if(p->state == RUNNABLE && p->priority < best){
        best   = p->priority;
        chosen = p;
      }
      release(&p->lock);
    }

    // ── Step 3: Run chosen process ───────────────────────────────────────────
    if(chosen != 0){
      acquire(&chosen->lock);
      // Re-check state: it may have changed between steps 2 and 3.
      if(chosen->state == RUNNABLE){
        chosen->state    = RUNNING;
        chosen->waittime = 0;   // reset aging counter when scheduled
        c->proc = chosen;

        start_tick = ticks;           // record start for runtime accounting
        swtch(&c->context, &chosen->context);
        chosen->runtime += ticks - start_tick;  // accumulate CPU time

        c->proc = 0;
      }
      release(&chosen->lock);
    }
  }
}

// Enter scheduler."""

# ─────────────────────────────────────────────────────────
# 3.  kernel/syscall.h  — new syscall numbers
# ─────────────────────────────────────────────────────────

SYSCALL_H_OLD = "#define SYS_close  21"
SYSCALL_H_NEW = """\
#define SYS_close       21
#define SYS_setpriority 22
#define SYS_psinfo      23"""

# ─────────────────────────────────────────────────────────
# 4.  kernel/syscall.c  — extern decls + dispatch table entries
# ─────────────────────────────────────────────────────────

SYSCALL_C_EXTERN_OLD = "extern uint64 sys_close(void);"
SYSCALL_C_EXTERN_NEW = """\
extern uint64 sys_close(void);
extern uint64 sys_setpriority(void);
extern uint64 sys_psinfo(void);"""

SYSCALL_C_TABLE_OLD = "[SYS_close]   sys_close,"
SYSCALL_C_TABLE_NEW = """\
[SYS_close]       sys_close,
[SYS_setpriority] sys_setpriority,
[SYS_psinfo]      sys_psinfo,"""

# ─────────────────────────────────────────────────────────
# 5.  kernel/sysproc.c  — two new system call implementations
# ─────────────────────────────────────────────────────────

NEW_SYSPROC_FUNCS = """
// ── New system calls ──────────────────────────────────────────────────────────

// setpriority(int pid, int priority)
//   Set the scheduling priority of the process identified by pid.
//   priority must be in [0, 20].  Returns 0 on success, -1 on error.
uint64
sys_setpriority(void)
{
  int pid, priority;
  if(argint(0, &pid) < 0 || argint(1, &priority) < 0)
    return -1;
  if(priority < MIN_PRIORITY || priority > MAX_PRIORITY)
    return -1;

  struct proc *p;
  for(p = proc; p < &proc[NPROC]; p++){
    acquire(&p->lock);
    if(p->pid == pid){
      p->priority = priority;
      p->waittime = 0;        // reset aging counter after manual adjustment
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
  }
  return -1;  // pid not found
}

// psinfo(void)
//   Print a snapshot of every non-UNUSED process to the console.
//   Returns the number of live processes printed.
uint64
sys_psinfo(void)
{
  static const char *state_names[] = {
    [UNUSED]   "UNUSED  ",
    [SLEEPING] "SLEEP   ",
    [RUNNABLE] "RUNNABLE",
    [RUNNING]  "RUNNING ",
    [ZOMBIE]   "ZOMBIE  ",
  };

  struct proc *p;
  int count = 0;

  printf("\\n%-6s %-16s %-8s %8s %12s %12s\\n",
         "PID", "NAME", "STATE", "PRIORITY", "RUNTIME", "STARTTIME");
  printf("------------------------------------------------------------------\\n");

  for(p = proc; p < &proc[NPROC]; p++){
    acquire(&p->lock);
    if(p->state != UNUSED){
      const char *st = (p->state >= 0 && p->state < 5)
                       ? state_names[p->state]
                       : "???     ";
      printf("%-6d %-16s %-8s %8d %12lu %12lu\\n",
             p->pid, p->name, st,
             p->priority, p->runtime, p->starttime);
      count++;
    }
    release(&p->lock);
  }
  printf("\\n");
  return count;
}
"""

# We also need to add the #defines that sysproc.c needs.
# The cleanest place is right before sys_setpriority.
# The same constants are already in proc.c via the patch above,
# but sysproc.c is a separate compilation unit, so it needs them too.
# We'll add them as a static local block.
NEW_SYSPROC_DEFINES = """\
// Priority constants (mirror those in proc.c)
#define MIN_PRIORITY  0
#define MAX_PRIORITY 20
"""

# ─────────────────────────────────────────────────────────
# 6.  user/user.h  — declare new syscalls for user programs
# ─────────────────────────────────────────────────────────

USER_H_OLD = "int uptime(void);"
USER_H_NEW = """\
int uptime(void);
int setpriority(int, int);
int psinfo(void);"""

# ─────────────────────────────────────────────────────────
# 7.  user/usys.pl  — add trampoline stubs
# ─────────────────────────────────────────────────────────

USYS_PL_OLD = 'entry("uptime");'
USYS_PL_NEW = '''\
entry("uptime");
entry("setpriority");
entry("psinfo");'''

# ─────────────────────────────────────────────────────────
# 8.  Makefile  — add test programs to UPROGS
# ─────────────────────────────────────────────────────────

MAKEFILE_OLD = "\t$U/_zombie\\"
MAKEFILE_NEW = """\
\t$U/_zombie\\
\t$U/_testpriority\\
\t$U/_testpsinfo\\"""

# ─────────────────────────────────────────────────────────
# Content for new user-space files
# ─────────────────────────────────────────────────────────

TESTPRIORITY_C = r"""// testpriority.c — tests the priority-based scheduler
//
// Spawns three child processes at priorities 5, 10, and 15.
// The child at priority 5 (highest urgency) should finish first,
// followed by 10, then 15.  The parent waits for all three and
// prints the finish order.  Also demonstrates setpriority().
#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

#define WORK_UNITS 200000000   // busy-work iterations per child

static void
spin(int n)
{
  volatile long x = 0;
  for(long i = 0; i < n; i++)
    x += i;
  (void)x;
}

int
main(void)
{
  printf("testpriority: starting\n");

  int pids[3];
  int prios[3] = {5, 10, 15};

  for(int i = 0; i < 3; i++){
    int pid = fork();
    if(pid == 0){
      // child: set our own priority then do work
      if(setpriority(getpid(), prios[i]) < 0)
        printf("  child %d: setpriority failed\n", getpid());
      printf("  child pid=%d priority=%d starting work\n",
             getpid(), prios[i]);
      spin(WORK_UNITS);
      printf("  child pid=%d priority=%d DONE\n", getpid(), prios[i]);
      exit(0);
    } else {
      pids[i] = pid;
      printf("parent: forked pid=%d with priority=%d\n", pid, prios[i]);
    }
  }

  // wait for all children
  for(int i = 0; i < 3; i++)
    wait(0);

  printf("testpriority: done\n");
  exit(0);
}
"""

TESTPSINFO_C = r"""// testpsinfo.c — tests the psinfo() system call
//
// Forks two children, then calls psinfo() so the process table is
// visible.  Also calls setpriority() to show dynamic priority changes.
#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int
main(void)
{
  printf("testpsinfo: calling psinfo() before fork\n");
  psinfo();

  int pid1 = fork();
  if(pid1 == 0){
    setpriority(getpid(), 3);   // high urgency
    printf("child1 (pid=%d, prio=3): sleeping briefly\n", getpid());
    sleep(5);
    exit(0);
  }

  int pid2 = fork();
  if(pid2 == 0){
    setpriority(getpid(), 18);  // low urgency
    printf("child2 (pid=%d, prio=18): sleeping briefly\n", getpid());
    sleep(5);
    exit(0);
  }

  sleep(1);  // let children settle

  printf("testpsinfo: calling psinfo() with children alive\n");
  psinfo();

  // change parent's own priority
  setpriority(getpid(), 7);
  printf("parent: set own priority to 7\n");

  psinfo();

  wait(0);
  wait(0);

  printf("testpsinfo: done\n");
  exit(0);
}
"""

# ─────────────────────────────────────────────────────────
# Main driver
# ─────────────────────────────────────────────────────────

def main():
  if len(sys.argv) != 2:
    print(__doc__)
    sys.exit(1)

  xv6 = sys.argv[1].rstrip("/")
  if not os.path.isdir(xv6):
    print(f"Error: '{xv6}' is not a directory.")
    sys.exit(1)

  print(f"\n=== Patching xv6-riscv at: {xv6} ===\n")

  # ── kernel/proc.h ───────────────────────────────────────
  print("[1] kernel/proc.h — adding struct proc fields")
  patch(f"{xv6}/kernel/proc.h", PROC_H_OLD, PROC_H_NEW)

  # ── kernel/proc.c ───────────────────────────────────────
  print("[2] kernel/proc.c — constants, allocproc init, scheduler")
  f = f"{xv6}/kernel/proc.c"
  # constants
  patch(f, PROC_C_CONST_ANCHOR, PROC_C_CONST_NEW)
  # allocproc init
  patch(f, ALLOC_PROC_FOUND_OLD, ALLOC_PROC_FOUND_NEW)
  # scheduler — replace from "void\nscheduler" up to "// Enter scheduler."
  text = read(f)
  start = text.find("void\nscheduler(void)\n{")
  end   = text.find("// Enter scheduler.  Must hold only p->lock")
  if start == -1 or end == -1:
    # Try alternative anchor
    end = text.find("\n// Enter scheduler.")
  if start != -1 and end != -1:
    old_sched = text[start:end]
    text = text[:start] + NEW_SCHEDULER + "\n" + text[end:]
    write(f, text)
  else:
    print("  [WARN] Could not locate scheduler() boundaries in proc.c")

  # ── kernel/syscall.h ────────────────────────────────────
  print("[3] kernel/syscall.h — adding SYS_setpriority, SYS_psinfo")
  patch(f"{xv6}/kernel/syscall.h", SYSCALL_H_OLD, SYSCALL_H_NEW)

  # ── kernel/syscall.c ────────────────────────────────────
  print("[4] kernel/syscall.c — extern declarations and dispatch table")
  f = f"{xv6}/kernel/syscall.c"
  patch(f, SYSCALL_C_EXTERN_OLD, SYSCALL_C_EXTERN_NEW)
  patch(f, SYSCALL_C_TABLE_OLD,  SYSCALL_C_TABLE_NEW)

  # ── kernel/sysproc.c ────────────────────────────────────
  print("[5] kernel/sysproc.c — sys_setpriority and sys_psinfo")
  f = f"{xv6}/kernel/sysproc.c"
  text = read(f)
  # Append the #defines and two new functions at the end of the file
  text = text.rstrip() + "\n\n" + NEW_SYSPROC_DEFINES + NEW_SYSPROC_FUNCS + "\n"
  write(f, text)

  # ── user/user.h ─────────────────────────────────────────
  print("[6] user/user.h — adding setpriority and psinfo declarations")
  patch(f"{xv6}/user/user.h", USER_H_OLD, USER_H_NEW)

  # ── user/usys.pl ────────────────────────────────────────
  print("[7] user/usys.pl — adding syscall stubs")
  patch(f"{xv6}/user/usys.pl", USYS_PL_OLD, USYS_PL_NEW)

  # ── Makefile ────────────────────────────────────────────
  print("[8] Makefile — adding _testpriority and _testpsinfo to UPROGS")
  patch(f"{xv6}/Makefile", MAKEFILE_OLD, MAKEFILE_NEW)

  # ── New user programs ────────────────────────────────────
  print("[9] Creating user/testpriority.c")
  write(f"{xv6}/user/testpriority.c", TESTPRIORITY_C)
  print("[9] Creating user/testpsinfo.c")
  write(f"{xv6}/user/testpsinfo.c", TESTPSINFO_C)

  print("""
=== Patching complete! ===

Next steps:
  cd """ + xv6 + """
  make clean && make qemu

Inside xv6 shell:
  testpriority        — verify priority ordering
  testpsinfo          — inspect process table via psinfo()
  Ctrl-A X            — exit QEMU
""")


if __name__ == "__main__":
  main()
