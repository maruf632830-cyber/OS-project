#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

#define WORK_UNITS 200000000

static void
spin(int n)
{
  volatile long x = 0;
  for(long i = 0; i < n; i++)
    x += i;
  (void)x;
}

int
main(void)
{
  printf("testpriority: starting\n");

  int pids[3];
  int prios[3] = {5, 10, 15};

  for(int i = 0; i < 3; i++){
    int pid = fork();
    if(pid == 0){
      if(setpriority(getpid(), prios[i]) < 0)
        printf("  child %d: setpriority failed\n", getpid());
      printf("  child pid=%d priority=%d starting work\n",
             getpid(), prios[i]);
      spin(WORK_UNITS);
      printf("  child pid=%d priority=%d DONE\n", getpid(), prios[i]);
      exit(0);
    } else {
      pids[i] = pid;
      printf("parent: forked pid=%d with priority=%d\n", pid, prios[i]);
    }
  }

  for(int i = 0; i < 3; i++)
    wait(0);

  printf("testpriority: done\n");
  exit(0);
}
