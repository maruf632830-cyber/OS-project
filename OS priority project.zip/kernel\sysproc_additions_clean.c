#define MIN_PRIORITY  0
#define MAX_PRIORITY 20

uint64
sys_setpriority(void)
{
  int pid, priority;
  if(argint(0, &pid) < 0 || argint(1, &priority) < 0)
    return -1;
  if(priority < MIN_PRIORITY || priority > MAX_PRIORITY)
    return -1;

  struct proc *p;
  for(p = proc; p < &proc[NPROC]; p++){
    acquire(&p->lock);
    if(p->pid == pid){
      p->priority = priority;
      p->waittime = 0;
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
  }
  return -1;
}

uint64
sys_psinfo(void)
{
  static const char *state_names[] = {
    [UNUSED]   "UNUSED  ",
    [SLEEPING] "SLEEP   ",
    [RUNNABLE] "RUNNABLE",
    [RUNNING]  "RUNNING ",
    [ZOMBIE]   "ZOMBIE  ",
  };

  struct proc *p;
  int count = 0;

  printf("\n%-6s %-16s %-8s %8s %12s %12s\n",
         "PID", "NAME", "STATE", "PRIORITY", "RUNTIME", "STARTTIME");
  printf("------------------------------------------------------------------\n");

  for(p = proc; p < &proc[NPROC]; p++){
    acquire(&p->lock);
    if(p->state != UNUSED){
      const char *st = (p->state >= 0 && p->state < 5)
                       ? state_names[p->state]
                       : "???     ";
      printf("%-6d %-16s %-8s %8d %12lu %12lu\n",
             p->pid, p->name, st,
             p->priority, p->runtime, p->starttime);
      count++;
    }
    release(&p->lock);
  }
  printf("\n");
  return count;
}
