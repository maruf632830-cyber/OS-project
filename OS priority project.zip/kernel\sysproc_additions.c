// ============================================================
// FILE: kernel/sysproc.c  — ADDITIONS
// Append this entire block to the END of the existing sysproc.c
// setup.py does this automatically.
// ============================================================

// Priority constants (mirror proc.c — both compilation units need them)
#define MIN_PRIORITY  0
#define MAX_PRIORITY 20

// ── sys_setpriority ───────────────────────────────────────────────────────────
// Prototype : int setpriority(int pid, int priority)
// Sets the scheduling priority of the process with the given pid.
// priority must be in [MIN_PRIORITY, MAX_PRIORITY].
// Returns 0 on success, -1 on error (invalid args or pid not found).
uint64
sys_setpriority(void)
{
  int pid, priority;
  if(argint(0, &pid) < 0 || argint(1, &priority) < 0)
    return -1;
  if(priority < MIN_PRIORITY || priority > MAX_PRIORITY)
    return -1;

  struct proc *p;
  for(p = proc; p < &proc[NPROC]; p++){
    acquire(&p->lock);
    if(p->pid == pid){
      p->priority = priority;
      p->waittime = 0;        // reset aging counter after manual adjustment
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
  }
  return -1;   // pid not found
}

// ── sys_psinfo ────────────────────────────────────────────────────────────────
// Prototype : int psinfo(void)
// Prints a formatted snapshot of every non-UNUSED process to the console.
// Columns : PID | NAME | STATE | PRIORITY | RUNTIME(ticks) | STARTTIME(tick)
// Returns the number of live processes printed.
uint64
sys_psinfo(void)
{
  static const char *state_names[] = {
    [UNUSED]   "UNUSED  ",
    [SLEEPING] "SLEEP   ",
    [RUNNABLE] "RUNNABLE",
    [RUNNING]  "RUNNING ",
    [ZOMBIE]   "ZOMBIE  ",
  };

  struct proc *p;
  int count = 0;

  printf("\n%-6s %-16s %-8s %8s %12s %12s\n",
         "PID", "NAME", "STATE", "PRIORITY", "RUNTIME", "STARTTIME");
  printf("------------------------------------------------------------------\n");

  for(p = proc; p < &proc[NPROC]; p++){
    acquire(&p->lock);
    if(p->state != UNUSED){
      const char *st = (p->state >= 0 && p->state < 5)
                       ? state_names[p->state]
                       : "???     ";
      printf("%-6d %-16s %-8s %8d %12lu %12lu\n",
             p->pid, p->name, st,
             p->priority, p->runtime, p->starttime);
      count++;
    }
    release(&p->lock);
  }
  printf("\n");
  return count;
}
