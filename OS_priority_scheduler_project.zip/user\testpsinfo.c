#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int
main(void)
{
  printf("testpsinfo: process table before any forks:\n");
  psinfo();

  int pid1 = fork();
  if(pid1 == 0){
    setpriority(getpid(), 3);
    printf("child1 (pid=%d, priority=3): running\n", getpid());
    sleep(10);
    exit(0);
  }

  int pid2 = fork();
  if(pid2 == 0){
    setpriority(getpid(), 18);
    printf("child2 (pid=%d, priority=18): running\n", getpid());
    sleep(10);
    exit(0);
  }

  sleep(2);

  printf("testpsinfo: process table with two sleeping children:\n");
  psinfo();

  printf("testpsinfo: setting parent (pid=%d) priority to 7\n", getpid());
  setpriority(getpid(), 7);

  printf("testpsinfo: process table after parent priority change:\n");
  psinfo();

  kill(pid1);
  kill(pid2);
  wait(0);
  wait(0);

  printf("testpsinfo: process table after children exit:\n");
  psinfo();

  printf("testpsinfo: PASS\n");
  exit(0);
}
