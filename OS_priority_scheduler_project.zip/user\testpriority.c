#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

#define WORK_UNITS 200000000

static void
spin(int n)
{
  volatile long x = 0;
  for(long i = 0; i < n; i++)
    x += i;
  (void)x;
}

int
main(void)
{
  printf("testpriority: starting (parent pid=%d)\n", getpid());
  printf("testpriority: spawning 3 children at priorities 5, 10, 15\n\n");

  int pids[3];
  int prios[3] = {5, 10, 15};

  for(int i = 0; i < 3; i++){
    int pid = fork();
    if(pid == 0){
      if(setpriority(getpid(), prios[i]) < 0)
        printf("  child %d: setpriority FAILED\n", getpid());
      printf("  child pid=%-5d priority=%-3d  [started]\n",
             getpid(), prios[i]);
      spin(WORK_UNITS);
      printf("  child pid=%-5d priority=%-3d  [FINISHED]\n",
             getpid(), prios[i]);
      exit(0);
    } else {
      pids[i] = pid;
    }
  }

  for(int i = 0; i < 3; i++)
    wait(0);

  printf("\ntestpriority: all children done\n");
  printf("Expected finish order: priority 5 -> 10 -> 15\n");

  printf("\ntestpriority: dynamic setpriority demo\n");
  int pid = fork();
  if(pid == 0){
    printf("  dynamic child pid=%d starting at priority 15\n", getpid());
    setpriority(getpid(), 15);
    sleep(1);
    printf("  dynamic child pid=%d boosted to priority 2\n", getpid());
    setpriority(getpid(), 2);
    spin(WORK_UNITS / 2);
    printf("  dynamic child pid=%d done\n", getpid());
    exit(0);
  }
  wait(0);

  printf("testpriority: PASS\n");
  exit(0);
}
