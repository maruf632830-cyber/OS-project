#!/usr/bin/env python3
import sys
import os
import shutil

def read(path):
    with open(path, "r") as f:
        return f.read()

def write(path, text):
    with open(path, "w") as f:
        f.write(text)
    print(f"  [OK] {path}")

def patch(path, old, new, count=1):
    text = read(path)
    if old not in text:
        print(f"  [WARN] anchor not found in {path}")
        return False
    text = text.replace(old, new, count)
    write(path, text)
    return True

def append(path, text):
    with open(path, "a") as f:
        f.write(text)
    print(f"  [OK] {path} (appended)")

def main():
    if len(sys.argv) != 2:
        print("Usage: python3 setup.py <path-to-xv6-riscv>")
        sys.exit(1)

    xv6_path = sys.argv[1]

    if not os.path.isdir(xv6_path):
        print(f"Error: {xv6_path} is not a directory")
        sys.exit(1)

    print("=" * 70)
    print("xv6 Priority Scheduler Patcher")
    print("=" * 70)

    script_dir = os.path.dirname(os.path.abspath(__file__))

    print("\n[1/6] Modifying kernel/proc.h — adding priority fields...")
    proc_h_path = os.path.join(xv6_path, "kernel", "proc.h")
    proc_h_anchor = '  char name[16];               // Process name (debugging)'
    proc_h_addition = """  int  priority;    // Scheduling priority: 0 (highest) – 20 (lowest), default 10
  uint64 runtime;   // Total CPU ticks consumed by this process
  uint64 waittime;  // Consecutive ticks spent RUNNABLE (aging counter)
  uint64 starttime; // Absolute system tick when this process was created"""

    if patch(proc_h_path, proc_h_anchor, proc_h_anchor + "\n" + proc_h_addition):
        print("  [OK] kernel/proc.h")
    else:
        print("  [FAIL] Could not patch kernel/proc.h")

    print("\n[2/6] Modifying kernel/proc.c — scheduler & initialization...")

    proc_c_path = os.path.join(xv6_path, "kernel", "proc.c")

    constants_code = """#define DEFAULT_PRIORITY  10
#define MAX_PRIORITY      20
#define MIN_PRIORITY       0
#define AGING_THRESHOLD   50

"""
    anchor = "#include \"kernel/param.h\"\n#include \"kernel/types.h\"\n"
    text = read(proc_c_path)
    if anchor in text:
        new_text = text.replace(anchor, anchor + constants_code, 1)
        write(proc_c_path, new_text)
    else:
        print("  [WARN] Could not find anchor in proc.c for constants")

    allocproc_anchor = "  p->context.sp = p->kstack + PGSIZE;"
    allocproc_addition = """  p->context.sp = p->kstack + PGSIZE;
  p->priority  = DEFAULT_PRIORITY;
  p->runtime   = 0;
  p->waittime  = 0;
  acquire(&tickslock);
  p->starttime = ticks;
  release(&tickslock);"""

    if patch(proc_c_path, allocproc_anchor, allocproc_addition):
        print("  [OK] kernel/proc.c (allocproc)")
    else:
        print("  [WARN] Could not patch allocproc in proc.c")

    scheduler_code = """void
scheduler(void)
{
  struct proc *p;
  struct proc *chosen;
  struct cpu  *c = mycpu();
  uint64 start_tick;

  c->proc = 0;
  for(;;){
    intr_on();

    for(p = proc; p < &proc[NPROC]; p++){
      acquire(&p->lock);
      if(p->state == RUNNABLE){
        p->waittime++;
        if(p->waittime >= AGING_THRESHOLD && p->priority > MIN_PRIORITY){
          p->priority--;
          p->waittime = 0;
        }
      }
      release(&p->lock);
    }

    chosen   = 0;
    int best = MAX_PRIORITY + 1;

    for(p = proc; p < &proc[NPROC]; p++){
      acquire(&p->lock);
      if(p->state == RUNNABLE && p->priority < best){
        best   = p->priority;
        chosen = p;
      }
      release(&p->lock);
    }

    if(chosen != 0){
      acquire(&chosen->lock);
      if(chosen->state == RUNNABLE){
        chosen->state    = RUNNING;
        chosen->waittime = 0;
        c->proc = chosen;

        start_tick = ticks;
        swtch(&c->context, &chosen->context);
        chosen->runtime += ticks - start_tick;

        c->proc = 0;
      }
      release(&chosen->lock);
    }
  }
}
"""

    text = read(proc_c_path)
    scheduler_start = text.find("void\nscheduler(void)")
    if scheduler_start != -1:
        scheduler_end = text.find("\n}\n", scheduler_start) + 3
        old_scheduler = text[scheduler_start:scheduler_end]
        new_text = text.replace(old_scheduler, scheduler_code, 1)
        write(proc_c_path, new_text)
        print("  [OK] kernel/proc.c (scheduler)")
    else:
        print("  [WARN] Could not find scheduler function in proc.c")

    print("\n[3/6] Modifying kernel/syscall.h — adding syscall numbers...")
    syscall_h_path = os.path.join(xv6_path, "kernel", "syscall.h")

    old_line = "#define SYS_close   21"
    new_lines = """#define SYS_close       21
#define SYS_setpriority 22
#define SYS_psinfo      23"""

    if patch(syscall_h_path, old_line, new_lines):
        print("  [OK] kernel/syscall.h")
    else:
        print("  [WARN] Could not patch kernel/syscall.h")

    print("\n[4/6] Modifying kernel/syscall.c — adding dispatch entries...")
    syscall_c_path = os.path.join(xv6_path, "kernel", "syscall.c")

    extern_anchor = "extern uint64 sys_unlink(void);"
    extern_addition = """extern uint64 sys_unlink(void);
extern uint64 sys_setpriority(void);
extern uint64 sys_psinfo(void);"""

    if patch(syscall_c_path, extern_anchor, extern_addition):
        print("  [OK] kernel/syscall.c (externs)")
    else:
        print("  [WARN] Could not patch externs in syscall.c")

    table_anchor = "[SYS_close]   sys_close,"
    table_addition = """[SYS_close]      sys_close,
  [SYS_setpriority] sys_setpriority,
  [SYS_psinfo]     sys_psinfo,"""

    if patch(syscall_c_path, table_anchor, table_addition):
        print("  [OK] kernel/syscall.c (syscall table)")
    else:
        print("  [WARN] Could not patch syscall table")

    print("\n[5/6] Appending to kernel/sysproc.c — system call implementations...")
    sysproc_c_path = os.path.join(xv6_path, "kernel", "sysproc.c")

    sysproc_code = """
#define MIN_PRIORITY  0
#define MAX_PRIORITY 20

uint64
sys_setpriority(void)
{
  int pid, priority;
  if(argint(0, &pid) < 0 || argint(1, &priority) < 0)
    return -1;
  if(priority < MIN_PRIORITY || priority > MAX_PRIORITY)
    return -1;

  struct proc *p;
  for(p = proc; p < &proc[NPROC]; p++){
    acquire(&p->lock);
    if(p->pid == pid){
      p->priority = priority;
      p->waittime = 0;
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
  }
  return -1;
}

uint64
sys_psinfo(void)
{
  static const char *state_names[] = {
    [UNUSED]   "UNUSED  ",
    [SLEEPING] "SLEEP   ",
    [RUNNABLE] "RUNNABLE",
    [RUNNING]  "RUNNING ",
    [ZOMBIE]   "ZOMBIE  ",
  };

  struct proc *p;
  int count = 0;

  printf("\\n%-6s %-16s %-8s %8s %12s %12s\\n",
         "PID", "NAME", "STATE", "PRIORITY", "RUNTIME", "STARTTIME");
  printf("------------------------------------------------------------------\\n");

  for(p = proc; p < &proc[NPROC]; p++){
    acquire(&p->lock);
    if(p->state != UNUSED){
      const char *st = (p->state >= 0 && p->state < 5)
                       ? state_names[p->state]
                       : "???     ";
      printf("%-6d %-16s %-8s %8d %12lu %12lu\\n",
             p->pid, p->name, st,
             p->priority, p->runtime, p->starttime);
      count++;
    }
    release(&p->lock);
  }
  printf("\\n");
  return count;
}
"""

    append(sysproc_c_path, sysproc_code)

    print("\n[6/6] Modifying user/user.h — adding syscall declarations...")
    user_h_path = os.path.join(xv6_path, "user", "user.h")

    user_h_anchor = "int unlink(const char*);"
    user_h_addition = """int unlink(const char*);
int setpriority(int, int);
int psinfo(void);"""

    if patch(user_h_path, user_h_anchor, user_h_addition):
        print("  [OK] user/user.h")
    else:
        print("  [WARN] Could not patch user/user.h")

    print("\n[7/7] Modifying user/usys.pl — adding syscall stubs...")
    usys_pl_path = os.path.join(xv6_path, "user", "usys.pl")

    usys_anchor = 'entry("unlink");'
    usys_addition = '''entry("unlink");
entry("setpriority");
entry("psinfo");'''

    if patch(usys_pl_path, usys_anchor, usys_addition):
        print("  [OK] user/usys.pl")
    else:
        print("  [WARN] Could not patch user/usys.pl")

    print("\n[8/8] Copying test programs...")

    testpriority_src = os.path.join(script_dir, "user", "testpriority_final.c")
    testpriority_dst = os.path.join(xv6_path, "user", "testpriority.c")
    if os.path.exists(testpriority_src):
        shutil.copy(testpriority_src, testpriority_dst)
        print(f"  [OK] user/testpriority.c")
    else:
        print(f"  [WARN] testpriority_final.c not found in {testpriority_src}")

    testpsinfo_src = os.path.join(script_dir, "user", "testpsinfo_final.c")
    testpsinfo_dst = os.path.join(xv6_path, "user", "testpsinfo.c")
    if os.path.exists(testpsinfo_src):
        shutil.copy(testpsinfo_src, testpsinfo_dst)
        print(f"  [OK] user/testpsinfo.c")
    else:
        print(f"  [WARN] testpsinfo_final.c not found in {testpsinfo_src}")

    print("\n[9/9] Modifying Makefile — adding test programs to UPROGS...")
    makefile_path = os.path.join(xv6_path, "Makefile")

    makefile_anchor = "$U/_zombie\\"
    makefile_addition = """$U/_zombie\\
  $U/_testpriority\\
  $U/_testpsinfo\\"""

    if patch(makefile_path, makefile_anchor, makefile_addition):
        print("  [OK] Makefile")
    else:
        print("  [WARN] Could not patch Makefile")

    print("\n" + "=" * 70)
    print("PATCHING COMPLETE!")
    print("=" * 70)
    print("\nNext steps:")
    print(f"  cd {xv6_path}")
    print("  make clean")
    print("  make qemu")
    print("\nInside the xv6 shell, run:")
    print("  testpriority")
    print("  testpsinfo")
    print("=" * 70 + "\n")

if __name__ == "__main__":
    main()
