# xv6 Priority Scheduler Project

## Overview

This project enhances the xv6-riscv operating system with:

| Feature | Description |
|---|---|
| **Priority-based scheduler** | Replaces default Round-Robin; selects the highest-urgency RUNNABLE process |
| **Round-Robin for equal priority** | Processes at the same priority level are time-shared in process table order |
| **Aging** | A RUNNABLE process that waits ≥ 50 ticks gets its priority boosted by 1, preventing starvation |
| **setpriority(pid, p)** | New system call — dynamically changes a process's priority at runtime |
| **psinfo()** | New system call — prints a snapshot of the live process table to the console |
| **Runtime tracking** | Every process records total CPU ticks consumed (runtime field) |

Priority range: **0 (highest urgency) → 20 (lowest urgency)**, default = **10**.

## Prerequisites

- QEMU with RISC-V support (qemu-system-riscv64)
- RISC-V cross-compiler (riscv64-linux-gnu-gcc or riscv64-unknown-elf-gcc)
- Python 3.6+
- A clean clone of xv6-riscv

Installation guide (Linux/macOS):
https://www.cse.iitb.ac.in/~mythili/os/xv6.html

## Quick Setup

### Automated Setup (Recommended)

```bash
# 1. Clone xv6-riscv (if you haven't already)
git clone https://github.com/mit-pdos/xv6-riscv.git

# 2. Run the setup script
python3 setup_final.py /path/to/xv6-riscv

# 3. Build and run
cd /path/to/xv6-riscv
make clean && make qemu
```

### Manual Setup

Follow the steps in MANUAL_PATCH_GUIDE.txt if you prefer to apply patches manually.

## Files Changed

### Kernel Modifications

| File | Changes |
|---|---|
| kernel/proc.h | Added priority, runtime, waittime, starttime fields to struct proc |
| kernel/proc.c | Added scheduler constants, priority initialization, new scheduler algorithm |
| kernel/syscall.h | Added SYS_setpriority (22), SYS_psinfo (23) |
| kernel/syscall.c | Added extern declarations and dispatch table entries |
| kernel/sysproc.c | Added sys_setpriority() and sys_psinfo() implementations |

### User Space

| File | Changes |
|---|---|
| user/user.h | Added setpriority and psinfo declarations |
| user/usys.pl | Added entry stubs for setpriority and psinfo |
| Makefile | Added testpriority and testpsinfo to UPROGS |

### New Programs

| File | Purpose |
|---|---|
| user/testpriority.c | Tests priority-based scheduling and dynamic priority adjustment |
| user/testpsinfo.c | Tests process monitoring via psinfo() system call |

## Running Tests

After building with `make qemu`, in the xv6 shell:

```
$ testpriority
testpriority: starting (parent pid=3)
testpriority: spawning 3 children at priorities 5, 10, 15

  child pid=4     priority=5    [started]
  child pid=5     priority=10   [started]
  child pid=6     priority=15   [started]
  child pid=4     priority=5    [FINISHED]
  child pid=5     priority=10   [FINISHED]
  child pid=6     priority=15   [FINISHED]

testpriority: all children done
Expected finish order: priority 5 -> 10 -> 15
testpriority: PASS
```

```
$ testpsinfo
testpsinfo: process table before any forks:

PID    NAME             STATE    PRIORITY     RUNTIME    STARTTIME
------------------------------------------------------------------
1      initcode         UNUSED       10            0            0
2      init             RUNNING      10            0            0

testpsinfo: process table with two sleeping children:

PID    NAME             STATE    PRIORITY     RUNTIME    STARTTIME
------------------------------------------------------------------
1      initcode         UNUSED       10            0            0
2      init             RUNNING      10       100000            0
3      testpsinfo       RUNNING      10        50000           50
4      [child1]         SLEEP         3        30000          100
5      [child2]         SLEEP        18        20000          120

testpsinfo: PASS
```

## System Call Reference

### setpriority(int pid, int priority)

Sets the scheduling priority of the process with the given PID.

**Parameters:**
- `pid`: Process ID
- `priority`: Priority value (0-20, where 0 is highest urgency)

**Returns:**
- 0 on success
- -1 on error (invalid arguments or PID not found)

**Behavior:**
- Resets the aging counter (waittime) when priority is changed
- Valid priority range: [0, 20]
- Default priority: 10

**Example:**
```c
setpriority(getpid(), 5);  // Set current process to high priority
```

### psinfo(void)

Prints a formatted snapshot of all non-UNUSED processes in the kernel's process table.

**Returns:**
- Number of processes printed

**Output Format:**
```
PID    NAME             STATE    PRIORITY     RUNTIME    STARTTIME
------------------------------------------------------------------
<pid> <name>           <state>  <priority>   <runtime>   <starttime>
```

**Example:**
```c
psinfo();  // Prints current process table
```

## Scheduler Algorithm

The priority scheduler implements:

1. **Aging**: Every scheduler iteration, each RUNNABLE process's waittime increments. When waittime ≥ 50 and priority > 0, priority is boosted (decremented) and waittime resets.

2. **Priority Selection**: The scheduler scans the process table and selects the RUNNABLE process with the smallest priority number (highest urgency).

3. **Round-Robin**: When multiple processes have equal priority, they are scheduled in process table order, creating a round-robin effect because the currently running process moves to RUNNING state.

4. **Runtime Tracking**: When a process runs, the scheduler records the start tick, runs the process, then adds the elapsed ticks to the process's runtime field.

## Priority Values

| Priority | Meaning |
|---|---|
| 0-3 | Critical/Real-time tasks |
| 4-7 | High priority |
| 8-12 | Normal priority (default = 10) |
| 13-17 | Low priority |
| 18-20 | Very low priority |

## Testing Notes

The priority order should be: **lower number = higher priority = runs first**

Example:
- Priority 2 process starts first
- Priority 10 process starts after priority 2 finishes
- Priority 18 process starts after priority 10 finishes

## Troubleshooting

**Compilation errors:**
- Ensure all .c files are copied to the xv6-riscv directory
- Run `make clean` before rebuilding
- Check for proper line endings (Unix/LF)

**Tests fail to run:**
- Verify the test programs were copied to user/
- Check Makefile includes testpriority and testpsinfo in UPROGS
- Ensure syscall numbers don't conflict with other syscalls

**Scheduler behaves incorrectly:**
- Verify kernel/proc.c scheduler() function was fully replaced
- Check that priority initialization in allocproc() is correct
- Verify syscall implementations in kernel/sysproc.c are present

## Project Structure

```
xv6_priority_project/
├── README.md                      (this file)
├── MANUAL_PATCH_GUIDE.txt         (step-by-step patching instructions)
├── setup_final.py                 (automated patch applicator)
├── kernel/
│   ├── proc_h_final.txt           (additions for proc.h)
│   ├── proc_c_constants.txt       (scheduler constants)
│   ├── proc_c_allocproc_init.txt  (initialization code)
│   ├── proc_c_scheduler.txt       (new scheduler function)
│   └── sysproc_additions_final.txt (setpriority, psinfo implementations)
├── user/
│   ├── testpriority_final.c       (priority scheduler test)
│   └── testpsinfo_final.c         (process monitoring test)
└── docs/
    └── OS Project Proposal.pdf    (detailed project specification)
```

## Implementation Details

### Struct proc additions

```c
int  priority;    // 0 (highest) to 20 (lowest), default 10
uint64 runtime;   // Total CPU ticks consumed
uint64 waittime;  // Consecutive RUNNABLE ticks (for aging)
uint64 starttime; // Absolute tick when process was created
```

### Scheduler Constants

```c
#define DEFAULT_PRIORITY   10
#define MAX_PRIORITY       20
#define MIN_PRIORITY        0
#define AGING_THRESHOLD    50
```

## Building and Running

```bash
cd /path/to/xv6-riscv
make clean
make qemu

# In xv6 shell:
$ testpriority
$ testpsinfo
$ ps  (to see process info)
```

## Notes

- All modifications are backward-compatible with xv6-riscv
- The aging mechanism prevents process starvation
- Runtime tracking uses tick-based accounting
- All syscalls are interrupt-safe via locking

## License

This project extends xv6-riscv, which is distributed under the MIT license.

## Author Notes

This implementation follows real-world OS scheduling principles used in systems like Linux. The combination of priority-based selection with aging and round-robin creates a fair yet responsive scheduler suitable for educational study of operating system design.
